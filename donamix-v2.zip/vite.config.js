import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
    build: {
        chunkSizeWarningLimit: 3000
    },
    plugins: [
        laravel(['resources/js/app.jsx', 'resources/css/app.css']),
        react(),
    ],
    resolve: {
        alias: {
            '@': path.resolve(__dirname, './resources/js'),
        },
    },
    define: {
        'process.env': process.env,
    },
    server: {
        // hmr: {
        //     host: 'localhost',
        // },
        host: '127.0.0.1',
    },
});
